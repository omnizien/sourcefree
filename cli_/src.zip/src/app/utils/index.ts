export const getFullUrl = gifId => {
  return `https://media.giphy.com/media/${gifId}/giphy.gif`;
};
