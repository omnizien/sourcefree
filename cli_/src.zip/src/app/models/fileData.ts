// import { Photo } from './photo';

export interface fileData {
 
  filename: string;
 
}