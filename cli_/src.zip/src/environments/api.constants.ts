export const API_KEY = "FUOjyQsmrVUVjEAoGfVe538blhej44Sj";
export const API_HOST = "https://api.giphy.com";
export const TRENDING_PATH = "/v1/gifs/trending";
export const RANDOM_PATH = "/v1/gifs/random";
export const SEARCH_PATH = "/v1/gifs/search";
